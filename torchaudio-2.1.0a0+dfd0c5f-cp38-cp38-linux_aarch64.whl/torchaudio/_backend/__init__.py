from .utils import get_info_func, get_load_func, get_save_func


info = get_info_func()
load = get_load_func()
save = get_save_func()
